# Pastel Blog 🌸💛

A simple pastel blog website made with HTML and CSS.

## Files

- `index.html` — the structure/content of the website.
- `style.css` — the colors, layout, fonts, spacing, and responsive design.

## How to use it

1. Upload `index.html` and `style.css` to your GitHub repository.
2. Make sure both files are in the same folder.
3. Open `index.html` in your browser, or enable GitHub Pages to publish the site.
4. Replace the sample blog text with your own writing.

## Easy customization

In `style.css`, look near the top for `:root`. The color variables are there so you can change the pastel palette easily.
